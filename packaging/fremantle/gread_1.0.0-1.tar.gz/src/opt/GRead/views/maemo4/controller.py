# -*- coding: utf-8 -*-

"""
GRead controller for maemo5
"""

from ..mobile.controller import Controller as MobileController

class Controller(MobileController):
    pass
